# CodeAlpha Object Detection and Tracking
Install dependencies and run `python detect_track.py`. Press Q to quit. The YOLO model downloads automatically on first run.