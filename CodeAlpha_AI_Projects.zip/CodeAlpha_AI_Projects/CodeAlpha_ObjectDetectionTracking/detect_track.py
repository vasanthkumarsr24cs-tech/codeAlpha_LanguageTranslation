import cv2
from ultralytics import YOLO
model=YOLO('yolov8n.pt')
cap=cv2.VideoCapture(0)
while cap.isOpened():
    ok,frame=cap.read()
    if not ok: break
    results=model.track(frame,persist=True,verbose=False)
    annotated=results[0].plot()
    cv2.imshow('CodeAlpha Object Detection and Tracking',annotated)
    if cv2.waitKey(1)&0xFF==ord('q'): break
cap.release(); cv2.destroyAllWindows()
