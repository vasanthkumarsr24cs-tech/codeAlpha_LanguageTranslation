# CodeAlpha Language Translation Tool
Open `index.html` in a browser and translate text using the Google Translate public endpoint.