# CodeAlpha Music Generation
Put MIDI files in `midi_data/`, install requirements, and run `python music_generator.py`.