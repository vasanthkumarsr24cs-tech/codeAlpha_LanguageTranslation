# AI Music Generation using music21 and TensorFlow
import glob, pickle, random, numpy as np
from music21 import converter, instrument, note, chord, stream
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from tensorflow.keras.callbacks import ModelCheckpoint
MIDI_DIR='midi_data/*.mid'; SEQ_LEN=50; EPOCHS=50; BATCH=64; N_GENERATE=300
def extract_notes():
    notes=[]
    for f in glob.glob(MIDI_DIR)[:100]:
        midi=converter.parse(f)
        parts=instrument.partitionByInstrument(midi)
        elements=parts.parts[0].recurse() if parts else midi.flat.notes
        for e in elements:
            if isinstance(e,note.Note): notes.append(str(e.pitch))
            elif isinstance(e,chord.Chord): notes.append('.'.join(map(str,e.normalOrder)))
    return notes
notes=extract_notes()
if len(notes)<=SEQ_LEN: raise SystemExit('Add more MIDI files to midi_data/')
vocab=sorted(set(notes)); to_int={n:i for i,n in enumerate(vocab)}
X=[]; y=[]
for i in range(len(notes)-SEQ_LEN):
    X.append([to_int[n] for n in notes[i:i+SEQ_LEN]]); y.append(to_int[notes[i+SEQ_LEN]])
X=np.reshape(X,(len(X),SEQ_LEN,1))/len(vocab)
y=np.eye(len(vocab))[y]
model=Sequential([LSTM(256,input_shape=(SEQ_LEN,1),return_sequences=True),Dropout(.2),LSTM(256),Dense(128,activation='relu'),Dense(len(vocab),activation='softmax')])
model.compile(loss='categorical_crossentropy',optimizer='adam')
model.fit(X,y,epochs=EPOCHS,batch_size=BATCH,callbacks=[ModelCheckpoint('best.keras',save_best_only=True)])
pattern=list(X[random.randrange(len(X))]*len(vocab)); result=[]
for _ in range(N_GENERATE):
    pred=model.predict(np.array(pattern).reshape(1,SEQ_LEN,1)/len(vocab) if max(pattern)>1 else np.array(pattern).reshape(1,SEQ_LEN,1),verbose=0)
    idx=int(np.argmax(pred)); result.append(vocab[idx]); pattern.append(idx); pattern=pattern[1:]
out=[]
for p in result:
    try: out.append(chord.Chord([int(x) for x in p.split('.')]))
    except: out.append(note.Note(p))
stream.Stream(out).write('midi',fp='generated_music.mid')
print('Saved generated_music.mid')
