# CodeAlpha AI Projects
This package contains all four tasks: Language Translation, FAQ Chatbot, Music Generation, and Object Detection & Tracking.
