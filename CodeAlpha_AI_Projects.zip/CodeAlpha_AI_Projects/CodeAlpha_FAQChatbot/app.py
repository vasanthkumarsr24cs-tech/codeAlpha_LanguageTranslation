from flask import Flask, render_template, request, jsonify
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
app=Flask(__name__)
faqs=[
("What is CodeAlpha?","CodeAlpha provides internship opportunities and practical technology projects."),
("How do I submit my project?","Upload your source code to GitHub and submit the required link through the official form."),
("How many tasks should I complete?","Complete the minimum number of tasks specified in your internship instructions."),
("What technologies are used?","This chatbot uses NLP with TF-IDF and cosine similarity.")
]
questions=[x[0] for x in faqs]
vectorizer=TfidfVectorizer(stop_words='english').fit(questions)
matrix=vectorizer.transform(questions)
@app.route('/')
def home(): return render_template('index.html')
@app.route('/chat',methods=['POST'])
def chat():
    q=request.json.get('question','')
    score=cosine_similarity(vectorizer.transform([q]),matrix)[0]
    i=score.argmax()
    answer=faqs[i][1] if score[i]>.08 else "Sorry, I could not find a matching FAQ."
    return jsonify(answer=answer)
if __name__=='__main__': app.run(debug=True)
