# CodeAlpha FAQ Chatbot
Install dependencies with `pip install -r requirements.txt`, then run `python app.py`.